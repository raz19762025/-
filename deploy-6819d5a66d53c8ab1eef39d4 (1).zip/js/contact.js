"use client";
import React, { useState } from "react";

function MainComponent() {
  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    email: "",
    deviceType: "",
    description: "",
    address: "",
  });
  const [predictions, setPredictions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [isAccessibilityOpen, setIsAccessibilityOpen] = useState(false);
  const [fontSize, setFontSize] = useState(16);
  const [highContrast, setHighContrast] = useState(false);

  const menuItems = [
    { id: 1, title: "דף הבית", path: "/" },
    { id: 2, title: "שירותי תיקון", path: "/repairs" },
    { id: 3, title: "מחירון", path: "/pricing" },
    { id: 4, title: "צור קשר", path: "/contact" },
  ];

  // שיפור הפונקציה עם טיפול בשגיאות טוב יותר ועצירת החיפוש אם הערך ריק
  const handleAddressSearch = async (value) => {
    if (!value || value.trim() === "") {
      setPredictions([]);
      return;
    }
    
    try {
      setIsLoading(true);
      const response = await fetch(
        `/integrations/google-place-autocomplete/autocomplete/json?input=${encodeURIComponent(value)}&radius=500`
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      
      const data = await response.json();
      setPredictions(data.predictions || []);
    } catch (err) {
      console.error("Error fetching address suggestions:", err);
      setPredictions([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddressSelect = (address) => {
    setFormData((prev) => ({ ...prev, address: address.description }));
    setPredictions([]);
  };

  // הוספת ולידציה בסיסית לטופס
  const validateForm = () => {
    const { fullName, phone, email } = formData;
    
    if (!fullName.trim()) {
      setError("יש להזין שם מלא");
      return false;
    }
    
    if (!phone.trim() || !/^\d{9,10}$/.test(phone.replace(/[- ]/g, ''))) {
      setError("יש להזין מספר טלפון תקין");
      return false;
    }
    
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setError("יש להזין כתובת אימייל תקינה");
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    
    // בדיקת תקינות הטופס
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);

    try {
      // כאן צריך להיות קוד אמיתי לשליחת הטופס לשרת
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      // איפוס הטופס לאחר שליחה מוצלחת
      setSuccess(true);
      setFormData({
        fullName: "",
        phone: "",
        email: "",
        deviceType: "",
        description: "",
        address: "",
      });
      
      // הסתרת הודעת ההצלחה לאחר 5 שניות
      setTimeout(() => {
        setSuccess(false);
      }, 5000);
    } catch (err) {
      setError("אירעה שגיאה בשליחת הטופס. אנא נסה שוב.");
    } finally {
      setIsLoading(false);
    }
  };

  // עדכון לטיפול ב-debounce בחיפוש כתובות
  const handleChange = (e) => {
    const { name, value } = e.target;
    
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    
    if (name === "address") {
      // הוספת השהייה קצרה לפני ביצוע חיפוש (debounce)
      const timeoutId = setTimeout(() => {
        handleAddressSearch(value);
      }, 300);
      
      // ניקוי ה-timeout הקודם אם קיים
      return () => clearTimeout(timeoutId);
    }
  };

  return (
    <div
      dir="rtl"
      className={`min-h-screen relative bg-gradient-to-br ${
        highContrast ? "from-black to-gray-900" : "from-[#0B1120] to-[#1E293B]"
      }`}
      style={{ fontSize: `${fontSize}px` }}
    >
      <div className="fixed left-4 top-1/2 transform -translate-y-1/2 z-50">
        <button
          onClick={() => setIsAccessibilityOpen(!isAccessibilityOpen)}
          className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-full shadow-lg"
          aria-label="אפשרויות נגישות"
        >
          <i className="fas fa-universal-access text-xl"></i>
        </button>

        {isAccessibilityOpen && (
          <div className="absolute left-0 mt-4 bg-white rounded-lg shadow-xl p-4 w-[250px]">
            <h3 className="text-gray-800 font-bold mb-3 text-right">
              הגדרות נגישות
            </h3>
            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <label className="text-gray-700 text-right">גודל טקסט</label>
                <div className="flex gap-2 justify-end">
                  <button
                    onClick={() =>
                      setFontSize((prev) => Math.min(prev + 2, 24))
                    }
                    className="bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded"
                  >
                    A+
                  </button>
                  <button
                    onClick={() =>
                      setFontSize((prev) => Math.max(prev - 2, 12))
                    }
                    className="bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded"
                  >
                    A-
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2">
                <label className="text-gray-700">ניגודיות גבוהה</label>
                <input
                  type="checkbox"
                  checked={highContrast}
                  onChange={(e) => setHighContrast(e.target.checked)}
                  className="w-4 h-4"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
        style={{
          backgroundImage:
            'url("https://ucarecdn.com/349241f8-f900-4806-a578-9bf2e9b6eb4d/")',
        }}
      ></div>
      <header className="relative z-10 bg-[#0B1120] bg-opacity-90 shadow-lg">
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-white">תיקון סלולר</div>
            <div className="hidden md:flex items-center space-x-6 space-x-reverse">
              {menuItems.map((item) => (
                <a
                  key={item.id}
                  href={item.path}
                  className="text-white hover:text-blue-400 transition duration-300"
                >
                  {item.title}
                </a>
              ))}
            </div>
            <button
              className="md:hidden text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label={isMenuOpen ? "סגור תפריט" : "פתח תפריט"}
            >
              <i className={`fas fa-${isMenuOpen ? "times" : "bars"} text-xl`}></i>
            </button>
          </div>

          {isMenuOpen && (
            <div className="mt-4 md:hidden">
              {menuItems.map((item) => (
                <a
                  key={item.id}
                  href={item.path}
                  className="block text-white py-2 hover:text-blue-400"
                >
                  {item.title}
                </a>
              ))}
            </div>
          )}
        </nav>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-12">
        <section className="text-center text-white mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">צור קשר</h1>
          <p className="text-xl md:text-2xl mb-8">נשמח לעמוד לשירותך</p>
        </section>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-white bg-opacity-10 p-8 rounded-lg shadow-xl">
            <h2 className="text-2xl font-bold text-white mb-6">שלח הודעה</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && <p className="text-red-500 text-center">{error}</p>}
              {success && (
                <p className="text-green-500 text-center">
                  ההודעה נשלחה בהצלחה!
                </p>
              )}

              <div>
                <label className="block text-white mb-2">שם מלא</label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-white mb-2">טלפון</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-white mb-2">אימייל</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-white mb-2">סוג המכשיר</label>
                <input
                  type="text"
                  name="deviceType"
                  value={formData.deviceType}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-white mb-2">תיאור הבעיה</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows="4"
                  className="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white"
                  required
                ></textarea>
              </div>
              <div className="relative">
                <label className="block text-white mb-2">כתובת</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white"
                  placeholder="הכנס כתובת"
                />
                {predictions.length > 0 && (
                  <div className="absolute z-10 w-full mt-1 bg-white rounded-lg shadow-lg">
                    {predictions.map((prediction) => (
                      <div
                        key={prediction.place_id}
                        onClick={() => handleAddressSelect(prediction)}
                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer text-gray-800"
                      >
                        {prediction.description}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg transition-all duration-300"
              >
                {isLoading ? "שולח..." : "שלח הודעה"}
              </button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="bg-white bg-opacity-10 p-8 rounded-lg shadow-xl">
              <h2 className="text-2xl font-bold text-white mb-6">
                פרטי התקשרות
              </h2>
              <div className="space-y-4 text-white">
                <div className="flex items-center gap-3">
                  <i className="fas fa-phone text-blue-400"></i>
                  <a href="tel:0508305885" className="hover:text-blue-400">
                    0508305885
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <i className="fas fa-envelope text-blue-400"></i>
                  <a
                    href="mailto:mobile.laboratory.b.s@gmail.com"
                    className="hover:text-blue-400"
                  >
                    mobile.laboratory.b.s@gmail.com
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <i className="fas fa-map-marker-alt text-blue-400"></i>
                  <span>באר שבע </span>
                </div>
                <div className="border-t border-white border-opacity-20 pt-4">
                  <h3 className="font-bold mb-2">שעות פעילות:</h3>
                  <p>ראשון - חמישי: 09:00 - 20:00</p>
                  <p>שישי: 09:00 - 14:00</p>
                  <p>שבת: סגור</p>
                </div>
              </div>
            </div>
            <div className="bg-white bg-opacity-10 p-8 rounded-lg shadow-xl">
              <h2 className="text-2xl font-bold text-white mb-6">
                המיקום שלנו
              </h2>
              <div className="h-[300px] bg-gray-300 rounded-lg">
                {/* כאן תוצג המפה לאחר בחירת האינטגרציה */}
              </div>
            </div>
            <div className="bg-white bg-opacity-10 p-8 rounded-lg shadow-xl">
              <h2 className="text-2xl font-bold text-white mb-6">
                עקבו אחרינו
              </h2>
              <div className="flex gap-4">
                <a href="#" className="text-white hover:text-blue-400 text-2xl">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="text-white hover:text-blue-400 text-2xl">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="text-white hover:text-blue-400 text-2xl">
                  <i className="fab fa-whatsapp"></i>
                </a>
                <a href="#" className="text-white hover:text-blue-400 text-2xl">
                  <i className="fab fa-telegram"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default MainComponent;