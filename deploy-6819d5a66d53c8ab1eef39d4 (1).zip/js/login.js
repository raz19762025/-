// JavaScript-only version of the login page
document.addEventListener("DOMContentLoaded", function () {
  // State variables
  let formData = { email: "", password: "" };
  let isLoading = false;
  let showContactsDialog = false;
  let contactsPermission = false;
  let error = "";
  let isMenuOpen = false;
  let messages = [];
  let userInput = "";
  let streamingMessage = "";
  let isLoggedIn = false;

  // DOM Elements
  const loginForm = document.getElementById("login-form");
  const emailInput = document.getElementById("email-input");
  const passwordInput = document.getElementById("password-input");
  const errorElement = document.getElementById("error-message");
  const loginButton = document.getElementById("login-button");
  const googleLoginButton = document.getElementById("google-login");
  const facebookLoginButton = document.getElementById("facebook-login");
  const menuButton = document.getElementById("menu-toggle");
  const mobileMenu = document.getElementById("mobile-menu");
  const chatForm = document.getElementById("chat-form");
  const chatInput = document.getElementById("chat-input");
  const messagesContainer = document.getElementById("chat-messages");
  const logoutButton = document.getElementById("logout-button");
  const contactsDialogContainer = document.getElementById("contacts-dialog-container");
  const contactsPermissionCheckbox = document.getElementById("privacy-checkbox");
  const skipContactsButton = document.getElementById("skip-contacts");
  const approveContactsButton = document.getElementById("approve-contacts");

  // Functions to update UI
  function renderMessages() {
    messagesContainer.innerHTML = "";
    
    messages.forEach(msg => {
      const messageDiv = document.createElement("div");
      messageDiv.className = `mb-4 ${msg.role === "user" ? "text-left" : "text-right"}`;
      
      const contentDiv = document.createElement("div");
      contentDiv.className = `inline-block p-3 rounded-lg ${
        msg.role === "user" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-800"
      }`;
      contentDiv.textContent = msg.content;
      
      messageDiv.appendChild(contentDiv);
      messagesContainer.appendChild(messageDiv);
    });
    
    if (streamingMessage) {
      const streamingDiv = document.createElement("div");
      streamingDiv.className = "text-right mb-4";
      
      const contentDiv = document.createElement("div");
      contentDiv.className = "inline-block p-3 rounded-lg bg-gray-200 text-gray-800";
      contentDiv.textContent = streamingMessage;
      
      streamingDiv.appendChild(contentDiv);
      messagesContainer.appendChild(streamingDiv);
    }
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function setErrorMessage(message) {
    error = message;
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.style.display = message ? "block" : "none";
    }
  }

  function toggleLoading(loading) {
    isLoading = loading;
    if (loginButton) {
      loginButton.disabled = loading;
      loginButton.textContent = loading ? "מתחבר..." : "התחבר";
    }
    
    if (googleLoginButton) {
      googleLoginButton.disabled = loading;
      const googleButtonText = googleLoginButton.querySelector("span");
      if (googleButtonText) {
        googleButtonText.textContent = loading ? "מתחבר..." : "התחבר עם Google";
      }
    }
    
    if (facebookLoginButton) {
      facebookLoginButton.disabled = loading;
      const facebookButtonText = facebookLoginButton.querySelector("span");
      if (facebookButtonText) {
        facebookButtonText.textContent = loading ? "מתחבר..." : "התחבר עם Facebook";
      }
    }
  }

  function toggleContactsDialog(show) {
    showContactsDialog = show;
    if (contactsDialogContainer) {
      contactsDialogContainer.style.display = show ? "flex" : "none";
    }
  }

  function toggleMenu() {
    isMenuOpen = !isMenuOpen;
    if (mobileMenu) {
      mobileMenu.style.display = isMenuOpen ? "block" : "none";
    }
  }

  function updateLoginState(loggedIn) {
    isLoggedIn = loggedIn;
    // Update UI based on login state
    if (logoutButton) {
      logoutButton.style.display = loggedIn ? "block" : "none";
    }
  }

  // Event handlers
  function handleSubmit(e) {
    e.preventDefault();
    toggleLoading(true);
    setErrorMessage("");

    try {
      // Simulate fetch request
      setTimeout(() => {
        // For demo purposes, always succeed with these credentials
        if (formData.email === "test@example.com" && formData.password === "password") {
          updateLoginState(true);
          toggleContactsDialog(true);
        } else {
          throw new Error("שם משתמש או סיסמה שגויים");
        }
        toggleLoading(false);
      }, 1000);
    } catch (err) {
      setErrorMessage(err.message);
      toggleLoading(false);
    }
  }

  function handleGoogleLogin() {
    setErrorMessage("פונקציונליות התחברות עם Google עדיין לא זמינה");
  }

  function handleFacebookLogin() {
    setErrorMessage("פונקציונליות התחברות עם Facebook עדיין לא זמינה");
  }

  function handleLogout() {
    updateLoginState(false);
    formData = { email: "", password: "" };
    if (emailInput) emailInput.value = "";
    if (passwordInput) passwordInput.value = "";
  }

  function handleChange(e) {
    const { name, value } = e.target;
    formData = { ...formData, [name]: value };
  }

  function handleChatSubmit(e) {
    e.preventDefault();
    if (!userInput.trim()) return;

    const newMessage = { role: "user", content: userInput };
    messages = [...messages, newMessage];
    userInput = "";
    if (chatInput) chatInput.value = "";
    
    renderMessages();

    // Simulate API call
    setTimeout(() => {
      streamingMessage = "אני מקבל את ההודעה שלך...";
      renderMessages();
      
      setTimeout(() => {
        streamingMessage = "";
        messages = [...messages, { 
          role: "assistant", 
          content: "תודה על פנייתך! כיצד אוכל לעזור לך היום?" 
        }];
        renderMessages();
      }, 1500);
    }, 500);
  }

  // Event listeners
  if (loginForm) {
    loginForm.addEventListener("submit", handleSubmit);
  }

  if (emailInput) {
    emailInput.addEventListener("input", handleChange);
  }
  
  if (passwordInput) {
    passwordInput.addEventListener("input", handleChange);
  }

  if (googleLoginButton) {
    googleLoginButton.addEventListener("click", handleGoogleLogin);
  }

  if (facebookLoginButton) {
    facebookLoginButton.addEventListener("click", handleFacebookLogin);
  }

  if (logoutButton) {
    logoutButton.addEventListener("click", handleLogout);
  }

  if (menuButton) {
    menuButton.addEventListener("click", toggleMenu);
  }

  if (chatForm) {
    chatForm.addEventListener("submit", handleChatSubmit);
  }

  if (chatInput) {
    chatInput.addEventListener("input", (e) => {
      userInput = e.target.value;
    });
  }

  if (contactsPermissionCheckbox) {
    contactsPermissionCheckbox.addEventListener("change", (e) => {
      contactsPermission = e.target.checked;
      if (approveContactsButton) {
        approveContactsButton.disabled = !contactsPermission;
      }
    });
  }

  if (skipContactsButton) {
    skipContactsButton.addEventListener("click", () => {
      toggleContactsDialog(false);
    });
  }

  if (approveContactsButton) {
    approveContactsButton.addEventListener("click", () => {
      toggleContactsDialog(false);
    });
  }

  // Initialize UI
  renderMessages();
  if (mobileMenu) {
    mobileMenu.style.display = "none";
  }
  if (logoutButton) {
    logoutButton.style.display = "none";
  }
  if (contactsDialogContainer) {
    contactsDialogContainer.style.display = "none";
  }
});

// Here's the HTML structure this script expects:
/*
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>מעבדה ניידת - התחברות</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
</head>
<body class="min-h-screen relative bg-gradient-to-br from-[#0B1120] to-[#1E293B]">
  <div class="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10" 
       style="background-image: url('https://ucarecdn.com/349241f8-f900-4806-a578-9bf2e9b6eb4d/')"></div>
  
  <header class="relative z-10 bg-[#0B1120] bg-opacity-90 shadow-lg">
    <nav class="container mx-auto px-4 py-4">
      <div class="flex items-center justify-between">
        <div class="text-2xl font-bold text-white">מעבדה ניידת</div>
        <div class="hidden md:flex items-center space-x-6 space-x-reverse">
          <a href="/" class="text-white hover:text-blue-400 transition duration-300">דף הבית</a>
          <a href="/repairs" class="text-white hover:text-blue-400 transition duration-300">שירותי תיקון</a>
          <a href="/pricing" class="text-white hover:text-blue-400 transition duration-300">מחירון</a>
          <a href="/contact" class="text-white hover:text-blue-400 transition duration-300">צור קשר</a>
          <button id="logout-button" class="text-white hover:text-red-400 transition duration-300">התנתק</button>
        </div>

        <button id="menu-toggle" class="md:hidden text-white">
          <i class="fas fa-bars text-xl"></i>
        </button>
      </div>

      <div id="mobile-menu" class="mt-4 md:hidden">
        <a href="/" class="block text-white py-2 hover:text-blue-400">דף הבית</a>
        <a href="/repairs" class="block text-white py-2 hover:text-blue-400">שירותי תיקון</a>
        <a href="/pricing" class="block text-white py-2 hover:text-blue-400">מחירון</a>
        <a href="/contact" class="block text-white py-2 hover:text-blue-400">צור קשר</a>
        <button id="mobile-logout" class="block w-full text-right text-white py-2 hover:text-red-400">התנתק</button>
      </div>
    </nav>
  </header>

  <main class="relative z-10 container mx-auto px-4 py-12">
    <section class="text-center text-white mb-16">
      <h1 class="text-4xl md:text-5xl font-bold mb-6">התחברות למערכת</h1>
      <p class="text-xl md:text-2xl mb-8">התחבר כדי לנהל את התיקונים שלך</p>
    </section>

    <div class="flex flex-col md:flex-row justify-center gap-8">
      <div class="bg-white bg-opacity-10 p-8 rounded-lg shadow-xl w-full max-w-md">
        <h2 class="text-3xl font-bold text-center mb-8 text-white">ברוכים הבאים</h2>
        <div class="space-y-4">
          <button id="google-login" class="w-full flex items-center justify-center gap-3 bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-all duration-300">
            <i class="fab fa-google text-xl"></i>
            <span>התחבר עם Google</span>
          </button>
          <button id="facebook-login" class="w-full flex items-center justify-center gap-3 bg-[#1877F2] hover:bg-[#1664D9] text-white px-6 py-3 rounded-lg transition-all duration-300">
            <i class="fab fa-facebook text-xl"></i>
            <span>התחבר עם Facebook</span>
          </button>
          <div class="relative my-6">
            <div class="absolute inset-0 flex items-center">
              <div class="w-full border-t border-white border-opacity-20"></div>
            </div>
            <div class="relative flex justify-center">
              <span class="px-4 text-sm text-white text-opacity-60 bg-[#1E293B]">או</span>
            </div>
          </div>

          <form id="login-form" class="space-y-4">
            <p id="error-message" class="text-red-500 text-center" style="display: none;"></p>
            <div class="space-y-2">
              <label class="block text-white text-right mb-1">אימייל</label>
              <input type="email" id="email-input" name="email" placeholder="הכנס את האימייל שלך" 
                     class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400" required>
            </div>
            <div class="space-y-2">
              <label class="block text-white text-right mb-1">סיסמה</label>
              <input type="password" id="password-input" name="password" placeholder="הכנס את הסיסמה שלך" 
                     class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400" required>
            </div>

            <button type="submit" id="login-button" 
                    class="w-full bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg transition-all duration-300">
              התחבר
            </button>
            <div class="mt-4 text-center">
              <a href="/forgot-password" class="text-blue-400 hover:text-blue-300">שכחת סיסמה?</a>
            </div>
          </form>
        </div>
      </div>

      <div class="bg-white bg-opacity-10 p-8 rounded-lg shadow-xl w-full max-w-md">
        <h2 class="text-3xl font-bold text-center mb-8 text-white">צ'אט תמיכה</h2>
        <div class="bg-white bg-opacity-10 rounded-lg p-4 h-[400px] flex flex-col">
          <div class="flex-grow overflow-y-auto mb-4" id="chat-messages">
            <!-- Chat messages will be inserted here by JavaScript -->
          </div>
          <form id="chat-form" class="flex gap-2">
            <input type="text" id="chat-input" placeholder="איך אני יכול לעזור לך?" 
                   class="flex-grow p-2 rounded-lg bg-white bg-opacity-20 text-white placeholder-white placeholder-opacity-60">
            <button type="submit" id="chat-submit" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50">
              שלח
            </button>
          </form>
        </div>
      </div>
    </div>

    <div id="contacts-dialog-container" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" style="display: none;">
      <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4">
        <h3 class="text-xl font-bold text-gray-800 mb-4">שיתוף אנשי קשר</h3>
        <p class="text-gray-600 mb-6">
          אנו מבקשים את רשותך לגשת לאנשי הקשר שלך כדי לשפר את חווית השימוש
          באפליקציה. המידע שלך מאובטח ולא יועבר לצד שלישי.
        </p>
        <div class="flex items-center mb-6">
          <input type="checkbox" id="privacy-checkbox" class="ml-2">
          <label for="privacy-checkbox" class="text-sm text-gray-600">קראתי ואני מסכים למדיניות הפרטיות</label>
        </div>
        <div class="flex justify-end gap-4">
          <button id="skip-contacts" class="px-4 py-2 text-gray-600 hover:text-gray-800">דלג</button>
          <button id="approve-contacts" disabled class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">אשר</button>
        </div>
      </div>
    </div>
  </main>

  <!-- Floating WhatsApp Button -->
  <a href="https://wa.me/+972000000000" target="_blank" rel="noopener noreferrer" 
     class="fixed bottom-4 right-4 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:bg-[#128C7E] transition-all duration-300 z-50" 
     aria-label="צור קשר בוואטסאפ">
    <i class="fab fa-whatsapp text-2xl"></i>
  </a>

  <!-- Floating Accessibility Button -->
  <button class="fixed bottom-4 left-4 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-all duration-300 z-50" 
          aria-label="אפשרויות נגישות">
    <i class="fas fa-universal-access text-2xl"></i>
  </button>

  <script src="script.js"></script>
</body>
</html>
*/