// JavaScript code for Mobile Lab Website
document.addEventListener('DOMContentLoaded', function() {
  // State variables
  let isAccessibilityMenuOpen = false;
  let fontSize = 16;
  let contrast = "normal";
  let isAuthenticated = false;
  let scrollProgress = 0;
  let showScrollTop = false;
  let isMobileMenuOpen = false;
  let showChatWidget = false;

  // Menu items data
  const menuItems = [
    { id: 1, title: "דף הבית", path: "#" },
    { id: 2, title: "תיקונים", path: "#repairs" },
    { id: 3, title: "צור קשר", path: "#contact" },
  ];
  
  const authItems = [
    { id: "login", title: "התחברות", path: "#login" },
    { id: "register", title: "הרשמה", path: "#register" },
  ];
  
  // Setup scroll handler
  window.addEventListener("scroll", function() {
    const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
    const currentProgress = (window.pageYOffset / totalScroll) * 100;
    scrollProgress = currentProgress;
    showScrollTop = window.pageYOffset > 300;
    
    // Update progress bar
    document.querySelector('.progress-bar').style.width = `${scrollProgress}%`;
    
    // Show/hide scroll-to-top button
    const scrollTopButton = document.getElementById('scrollTopButton');
    if (scrollTopButton) {
      if (showScrollTop) {
        scrollTopButton.classList.remove('hidden');
      } else {
        scrollTopButton.classList.add('hidden');
      }
    }
  });
  
  // Create the HTML structure
  const app = document.getElementById('app');
  app.dir = "rtl";
  app.className = "min-h-screen relative bg-[#1E293B] overflow-x-hidden";
  
  // Create and append HTML elements
  app.innerHTML = `
    <div class="fixed top-0 left-0 right-0 h-1 bg-[#1E293B] z-50">
      <div class="progress-bar h-full bg-[#0EA5E9] transition-all duration-300" style="width: 0%"></div>
    </div>
    
    <button id="scrollTopButton" onclick="scrollToTop()" class="fixed bottom-8 right-8 bg-[#0EA5E9] text-white p-4 rounded-full shadow-lg hover:bg-[#0284C7] transition-all duration-300 z-50 hidden">
      <i class="fas fa-arrow-up"></i>
    </button>
    
    <div class="fixed inset-0 bg-cover bg-center bg-no-repeat opacity-15 pointer-events-none" 
         style="background-image: url('https://ucarecdn.com/51899500-9aa6-46fa-bd35-0d53ebb86acf/'); background-attachment: fixed;"></div>
    
    <header class="sticky top-0 z-50 bg-[#334155]/95 backdrop-blur-sm shadow-lg">
      <nav class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
          <div class="text-xl sm:text-2xl font-bold text-white">
            מעבדה ניידת
          </div>

          <div class="hidden lg:flex items-center space-x-8 space-x-reverse">
            ${menuItems.map(item => `
              <a href="${item.path}" class="text-white hover:text-[#0EA5E9] transition duration-300 text-lg">
                ${item.title}
              </a>
            `).join('')}
          </div>

          <div class="hidden lg:flex items-center gap-4" id="auth-buttons">
            ${authItems.map(item => `
              <button 
                data-id="${item.id}"
                class="auth-button text-white transition duration-300 px-6 py-2 rounded-lg text-lg
                  ${item.id === "register" ? "bg-[#0EA5E9] hover:bg-[#0284C7]" : "hover:bg-[#475569]"}"
              >
                ${item.title}
              </button>
            `).join('')}
          </div>

          <button id="mobileMenuToggle" class="lg:hidden text-white p-2 hover:bg-[#475569] rounded-lg">
            <i class="fas fa-bars text-2xl"></i>
          </button>
        </div>

        <div id="mobileMenu" class="lg:hidden mt-4 py-4 border-t border-[#475569] animate-fadeIn hidden">
          <div class="flex flex-col space-y-4">
            ${menuItems.map(item => `
              <a href="${item.path}" class="text-white hover:text-[#0EA5E9] transition duration-300 text-lg px-2">
                ${item.title}
              </a>
            `).join('')}
            
            ${authItems.map(item => `
              <button 
                data-id="${item.id}"
                class="auth-button text-white transition duration-300 px-4 py-2 rounded-lg text-lg w-full text-right
                  ${item.id === "register" ? "bg-[#0EA5E9] hover:bg-[#0284C7]" : "hover:bg-[#475569]"}"
              >
                ${item.title}
              </button>
            `).join('')}
          </div>
        </div>
      </nav>
    </header>
    
    <main class="relative z-10 container mx-auto px-4 py-6 sm:py-8 lg:py-12">
      <section class="text-center text-white mb-12 md:mb-16 animate-fadeInUp">
        <h1 class="text-4xl sm:text-5xl md:text-7xl font-extrabold mb-4 md:mb-6 bg-gradient-to-r from-[#0EA5E9] to-[#3B82F6] text-transparent bg-clip-text transform transition-all duration-300 hover:scale-105">
          מעבדה ניידת לתיקון מכשירים
        </h1>
        <p class="text-lg sm:text-xl md:text-2xl mb-6 md:mb-8 px-2">
          המומחים שלנו מספקים פתרונות מהירים ואיכותיים לכל בעיה
        </p>
        <div class="flex flex-col sm:flex-row justify-center gap-4 mb-8 md:mb-12">
          <div class="bg-[#334155] p-4 rounded-lg w-full sm:w-auto">
            <i class="fas fa-clock text-[#0EA5E9] text-2xl"></i>
            <p class="text-sm mt-2">זמן תגובה ממוצע: 15 דקות</p>
          </div>
          <div class="bg-[#334155] p-4 rounded-lg w-full sm:w-auto">
            <i class="fas fa-star text-[#0EA5E9] text-2xl"></i>
            <p class="text-sm mt-2">דירוג שירות: 4.9/5</p>
          </div>
        </div>
        <button id="orderRepairButton" class="inline-block bg-[#0EA5E9] text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg hover:bg-[#0284C7] transition-all duration-300 transform hover:scale-105 hover:shadow-lg w-full sm:w-auto">
          הזמן תיקון עכשיו
        </button>
      </section>
      
      <section class="mb-12 md:mb-16 animate-fadeInUp">
        <h2 class="text-2xl md:text-3xl font-bold mb-6 md:mb-8 text-center text-white">
          לקוחות ממליצים
        </h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8">
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <div class="flex items-center mb-4">
              <i class="fas fa-user-circle text-4xl text-[#0EA5E9] ml-4"></i>
              <div>
                <h3 class="font-bold">דני כהן</h3>
                <div class="text-[#0EA5E9]">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
              </div>
            </div>
            <p>"שירות מעולה ומקצועי. תיקנו את האייפון שלי תוך שעה!"</p>
          </div>
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <div class="flex items-center mb-4">
              <i class="fas fa-user-circle text-4xl text-[#0EA5E9] ml-4"></i>
              <div>
                <h3 class="font-bold">מירי לוי</h3>
                <div class="text-[#0EA5E9]">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
              </div>
            </div>
            <p>"מחירים הוגנים ושירות אדיב. ממליצה בחום!"</p>
          </div>
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <div class="flex items-center mb-4">
              <i class="fas fa-user-circle text-4xl text-[#0EA5E9] ml-4"></i>
              <div>
                <h3 class="font-bold">יוסי אברהם</h3>
                <div class="text-[#0EA5E9]">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                </div>
              </div>
            </div>
            <p>"המקצוענים האמיתיים בתחום. תודה רבה על השירות!"</p>
          </div>
        </div>
      </section>
      
      <section class="text-center text-white mb-12 md:mb-16 animate-scaleIn">
        <h2 class="text-2xl md:text-3xl font-bold mb-6 md:mb-8">
          המותגים שאנחנו מתקנים
        </h2>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-6 justify-items-center">
          <div class="text-center transform transition-all duration-300 hover:scale-110">
            <i class="fab fa-apple text-[#0EA5E9] text-5xl sm:text-6xl mb-2"></i>
            <p>אייפון</p>
          </div>
          <div class="text-center transform transition-all duration-300 hover:scale-110">
            <i class="fab fa-android text-[#0EA5E9] text-5xl sm:text-6xl mb-2"></i>
            <p>סמסונג</p>
          </div>
          <div class="text-center transform transition-all duration-300 hover:scale-110">
            <i class="fas fa-mobile-alt text-[#0EA5E9] text-5xl sm:text-6xl mb-2"></i>
            <p>שיאומי</p>
          </div>
          <div class="text-center transform transition-all duration-300 hover:scale-110">
            <i class="fas fa-mobile text-[#0EA5E9] text-5xl sm:text-6xl mb-2"></i>
            <p>וואווי</p>
          </div>
        </div>
      </section>
      
      <section class="text-center text-white mt-16">
        <h2 class="text-3xl font-bold mb-8">תיקון מחשבים ניידים</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <i class="fas fa-laptop text-4xl mb-4 text-[#0EA5E9]"></i>
            <h3 class="text-xl font-bold mb-2">החלפת מסך</h3>
            <p>תיקון והחלפת מסכים שבורים או פגומים</p>
            <p class="mt-2 text-[#0EA5E9]">החל מ-₪450</p>
          </div>
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <i class="fas fa-memory text-4xl mb-4 text-[#0EA5E9]"></i>
            <h3 class="text-xl font-bold mb-2">שדרוג חומרה</h3>
            <p>שדרוג זיכרון RAM וכונן SSD</p>
            <p class="mt-2 text-[#0EA5E9]">החל מ-₪299</p>
          </div>
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <i class="fas fa-battery-full text-4xl mb-4 text-[#0EA5E9]"></i>
            <h3 class="text-xl font-bold mb-2">החלפת סוללה</h3>
            <p>החלפת סוללות שאינן מחזיקות טעינה</p>
            <p class="mt-2 text-[#0EA5E9]">החל מ-₪349</p>
          </div>
        </div>
        
        <h2 class="text-3xl font-bold mb-8">תיקון מחשבים נייחים</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <i class="fas fa-desktop text-4xl mb-4 text-[#0EA5E9]"></i>
            <h3 class="text-xl font-bold mb-2">הרכבת מחשב</h3>
            <p>הרכבת מחשב מותאם אישית לפי דרישות</p>
            <p class="mt-2 text-[#0EA5E9]">החל מ-₪299</p>
          </div>
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <i class="fas fa-microchip text-4xl mb-4 text-[#0EA5E9]"></i>
            <h3 class="text-xl font-bold mb-2">שדרוג מעבד</h3>
            <p>החלפה ושדרוג מעבדים לביצועים משופרים</p>
            <p class="mt-2 text-[#0EA5E9]">החל מ-₪399</p>
          </div>
          <div class="bg-[#334155] p-6 rounded-lg shadow-lg text-white">
            <i class="fas fa-fan text-4xl mb-4 text-[#0EA5E9]"></i>
            <h3 class="text-xl font-bold mb-2">ניקוי וקירור</h3>
            <p>ניקוי אבק והחלפת משחת קירור</p>
            <p class="mt-2 text-[#0EA5E9]">החל מ-₪199</p>
          </div>
        </div>
      </section>
    </main>
    
    <button id="chatToggleButton" class="fixed bottom-20 right-4 md:bottom-24 md:right-8 bg-[#0EA5E9] text-white p-3 md:p-4 rounded-full shadow-lg hover:bg-[#0284C7] transition-all duration-300 z-50">
      <i class="fas fa-comments text-lg md:text-xl"></i>
    </button>
    
    <div id="chatWidget" class="fixed bottom-24 right-4 w-[95vw] sm:w-[400px] max-w-[400px] bg-white rounded-xl shadow-2xl z-50 animate-slideIn hidden">
      <div class="p-4 bg-[#0EA5E9] text-white rounded-t-xl flex justify-between items-center">
        <span class="text-lg font-medium">צ'אט תמיכה</span>
        <button id="closeChatButton" class="hover:bg-[#0284C7] p-2 rounded-lg transition-colors">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="p-4">
        <p class="text-gray-600 mb-4">כיצד נוכל לעזור לך?</p>
        <textarea
          class="w-full p-3 border border-gray-300 rounded-lg mb-3 focus:outline-none focus:border-[#0EA5E9]"
          placeholder="הקלד את הודעתך כאן..."
          rows="3"
        ></textarea>
        <button class="w-full bg-[#0EA5E9] text-white py-3 rounded-lg hover:bg-[#0284C7] transition-duration-300 font-medium">
          שלח
        </button>
      </div>
    </div>
  `;
  
  // Add CSS
  const styles = document.createElement('style');
  styles.innerHTML = `
    html {
      -webkit-text-size-adjust: 100%;
      scroll-behavior: smooth;
    }

    body {
      overflow-x: hidden;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-overflow-scrolling: touch;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(100%);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .animate-fadeIn {
      animation: fadeIn 0.3s ease-out forwards;
    }

    .animate-fadeInUp {
      animation: fadeInUp 0.5s ease-out forwards;
    }

    .animate-slideIn {
      animation: slideIn 0.3s ease-out forwards;
    }

    .animate-slideDown {
      animation: slideDown 0.3s ease-out forwards;
    }
    
    .hidden {
      display: none;
    }

    input, textarea, button {
      appearance: none;
      -webkit-appearance: none;
      border-radius: 0;
    }

    @media (max-width: 768px) {
      input, textarea, select {
        font-size: 16px !important;
      }
      
      img {
        max-width: 100%;
        height: auto;
      }
    }

    @media (min-width: 769px) and (max-width: 1024px) {
      body {
        -webkit-overflow-scrolling: touch;
      }
    }
  `;
  document.head.appendChild(styles);
  
  // Add event listeners after DOM has loaded
  // Mobile menu toggle
  document.getElementById('mobileMenuToggle').addEventListener('click', function() {
    const mobileMenu = document.getElementById('mobileMenu');
    const menuIcon = this.querySelector('i');
    
    isMobileMenuOpen = !isMobileMenuOpen;
    
    if (isMobileMenuOpen) {
      mobileMenu.classList.remove('hidden');
      menuIcon.classList.remove('fa-bars');
      menuIcon.classList.add('fa-times');
    } else {
      mobileMenu.classList.add('hidden');
      menuIcon.classList.remove('fa-times');
      menuIcon.classList.add('fa-bars');
    }
  });
  
  // Chat widget toggle
  document.getElementById('chatToggleButton').addEventListener('click', function() {
    const chatWidget = document.getElementById('chatWidget');
    showChatWidget = !showChatWidget;
    
    if (showChatWidget) {
      chatWidget.classList.remove('hidden');
    } else {
      chatWidget.classList.add('hidden');
    }
  });
  
  // Close chat button
  document.getElementById('closeChatButton').addEventListener('click', function() {
    document.getElementById('chatWidget').classList.add('hidden');
    showChatWidget = false;
  });
  
  // Order repair button
  document.getElementById('orderRepairButton').addEventListener('click', function() {
    window.location.href = "/repairs";
  });
  
  // Auth buttons
  document.querySelectorAll('.auth-button').forEach(button => {
    button.addEventListener('click', function() {
      window.location.href = "/repairs";
    });
  });
});

// Scroll to top function (needs to be global for inline event handlers)
function scrollToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}