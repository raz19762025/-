document.addEventListener('DOMContentLoaded', function() {
  // ניהול מצב (state)
  let isMenuOpen = false;
  let selectedCategory = "הכל";
  let formData = {
    name: "",
    phone: "",
    email: "",
    deviceType: "",
    issue: ""
  };

  // נתונים
  const menuItems = [
    { id: 1, title: "דף הבית", path: "/" },
    { id: 2, title: "שירותי תיקון", path: "/repairs" },
    { id: 3, title: "מחירון", path: "/pricing" },
    { id: 4, title: "צור קשר", path: "/contact" }
  ];

  const categories = ["הכל", "מסך", "סוללה", "מצלמה", "רמקול", "תוכנה"];

  const services = [
    {
      id: 1,
      name: "החלפת מסך",
      category: "מסך",
      description: "תיקון והחלפת מסכים שבורים או פגומים",
      priceRange: "200-800 ₪",
      icon: "fa-mobile-screen"
    },
    {
      id: 2,
      name: "החלפת סוללה",
      category: "סוללה",
      description: "החלפת סוללות ישנות או פגומות",
      priceRange: "150-400 ₪",
      icon: "fa-battery-full"
    },
    {
      id: 3,
      name: "תיקון מצלמה",
      category: "מצלמה",
      description: "תיקון מצלמות קדמיות ואחוריות",
      priceRange: "200-600 ₪",
      icon: "fa-camera"
    },
    {
      id: 4,
      name: "תיקון רמקולים",
      category: "רמקול",
      description: "תיקון בעיות שמע ורמקולים",
      priceRange: "150-350 ₪",
      icon: "fa-volume-high"
    },
    {
      id: 5,
      name: "עדכוני תוכנה",
      category: "תוכנה",
      description: "טיפול בבעיות תוכנה ועדכוני מערכת",
      priceRange: "100-300 ₪",
      icon: "fa-gear"
    },
    {
      id: 6,
      name: "שחזור מידע",
      category: "תוכנה",
      description: "שחזור תמונות ומידע שנמחק",
      priceRange: "200-700 ₪",
      icon: "fa-database"
    }
  ];

  // יצירת HTML ומבנה העמוד
  function createPageStructure() {
    const body = document.body;
    body.setAttribute('dir', 'rtl');
    body.className = 'min-h-screen relative bg-gradient-to-br from-[#0B1120] to-[#1E293B]';
    
    // רקע
    const background = document.createElement('div');
    background.className = 'absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10';
    background.style.backgroundImage = 'url("https://ucarecdn.com/349241f8-f900-4806-a578-9bf2e9b6eb4d/")';
    body.appendChild(background);
    
    // הוספת התוכן הראשי
    body.innerHTML += `
      <header class="relative z-10 bg-[#0B1120] bg-opacity-90 shadow-lg">
        <nav class="container mx-auto px-4 py-4">
          <div class="flex items-center justify-between">
            <div class="text-2xl font-bold text-white">מעבדה ניידת</div>
            <div class="hidden md:flex items-center space-x-6 space-x-reverse" id="desktop-menu">
              ${menuItems.map(item => `
                <a href="${item.path}" class="text-white hover:text-blue-400 transition duration-300">
                  ${item.title}
                </a>
              `).join('')}
            </div>
            <button class="md:hidden text-white" id="mobile-menu-toggle">
              <i class="fas fa-bars text-xl"></i>
            </button>
          </div>

          <div class="mt-4 md:hidden hidden" id="mobile-menu">
            ${menuItems.map(item => `
              <a href="${item.path}" class="block text-white py-2 hover:text-blue-400">
                ${item.title}
              </a>
            `).join('')}
          </div>
        </nav>
      </header>

      <main class="relative z-10 container mx-auto px-4 py-12">
        <section class="text-center text-white mb-16">
          <h1 class="text-4xl md:text-5xl font-bold mb-6">שירותי תיקון</h1>
          <p class="text-xl md:text-2xl mb-8">המומחים שלנו כאן בשבילכם</p>
        </section>
        
        <div class="flex justify-center mb-8 gap-4 flex-wrap" id="categories-container">
          ${categories.map(category => `
            <button 
              data-category="${category}"
              class="category-btn px-4 py-2 rounded-full transition-all duration-300 ${
                category === selectedCategory 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-white bg-opacity-10 text-white hover:bg-opacity-20'
              }"
            >
              ${category}
            </button>
          `).join('')}
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16" id="services-container">
          ${renderServices()}
        </div>

        <section class="max-w-2xl mx-auto bg-white bg-opacity-10 p-8 rounded-lg">
          <h2 class="text-3xl font-bold text-white text-center mb-8">צור קשר לתיקון</h2>
          <form id="contact-form" class="space-y-6">
            <div>
              <label class="block text-white mb-2">שם מלא</label>
              <input
                type="text"
                name="name"
                class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                required
              />
            </div>
            <div>
              <label class="block text-white mb-2">טלפון</label>
              <input
                type="tel"
                name="phone"
                class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                required
              />
            </div>
            <div>
              <label class="block text-white mb-2">אימייל</label>
              <input
                type="email"
                name="email"
                class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                required
              />
            </div>
            <div>
              <label class="block text-white mb-2">סוג המכשיר</label>
              <input
                type="text"
                name="deviceType"
                class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                required
              />
            </div>
            <div>
              <label class="block text-white mb-2">תיאור הבעיה</label>
              <textarea
                name="issue"
                rows="4"
                class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-white placeholder-opacity-60 focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
                required
              ></textarea>
            </div>
            <button
              type="submit"
              class="w-full bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg transition-all duration-300"
            >
              שלח בקשה
            </button>
          </form>
        </section>
      </main>
    `;
    
    // הוספת מאזיני אירועים
    addEventListeners();
  }
  
  // פונקציה לרינדור השירותים המסוננים
  function renderServices() {
    const filteredServices = selectedCategory === "הכל" 
      ? services 
      : services.filter(service => service.category === selectedCategory);
      
    return filteredServices.map(service => `
      <div class="bg-white bg-opacity-10 rounded-lg p-6 text-white hover:transform hover:scale-105 transition-all duration-300">
        <div class="text-4xl mb-4 text-blue-400">
          <i class="fas ${service.icon}"></i>
        </div>
        <h3 class="text-xl font-bold mb-2">${service.name}</h3>
        <p class="text-gray-300 mb-4">${service.description}</p>
        <p class="text-lg font-semibold mb-4">${service.priceRange}</p>
        <a
          href="/pricing"
          class="block w-full bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-all duration-300 text-center"
        >
          תיקונים
        </a>
      </div>
    `).join('');
  }
  
  // הוספת מאזיני אירועים
  function addEventListeners() {
    // התפריט הנייד
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuToggle) {
      mobileMenuToggle.addEventListener('click', function() {
        isMenuOpen = !isMenuOpen;
        mobileMenu.classList.toggle('hidden', !isMenuOpen);
      });
    }
    
    // לחצני הקטגוריות
    const categoryButtons = document.querySelectorAll('.category-btn');
    categoryButtons.forEach(button => {
      button.addEventListener('click', function() {
        const category = this.getAttribute('data-category');
        selectedCategory = category;
        
        // עדכון סגנון הלחצנים
        categoryButtons.forEach(btn => {
          if (btn.getAttribute('data-category') === category) {
            btn.classList.remove('bg-white', 'bg-opacity-10');
            btn.classList.add('bg-blue-500', 'text-white');
          } else {
            btn.classList.remove('bg-blue-500', 'text-white');
            btn.classList.add('bg-white', 'bg-opacity-10');
          }
        });
        
        // רינדור מחדש של השירותים
        const servicesContainer = document.getElementById('services-container');
        servicesContainer.innerHTML = renderServices();
      });
    });
    
    // הטופס
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
      contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // אוסף את הנתונים מהטופס
        const formElements = contactForm.elements;
        formData = {
          name: formElements.name.value,
          phone: formElements.phone.value,
          email: formElements.email.value,
          deviceType: formElements.deviceType.value,
          issue: formElements.issue.value
        };
        
        // כאן אפשר להוסיף קוד לשליחת הטופס לשרת
        console.log('נתוני הטופס:', formData);
        alert('הטופס נשלח בהצלחה!');
        contactForm.reset();
      });
      
      // מאזיני אירועים לעדכון ה-state עם שינוי בשדות הטופס
      const formInputs = contactForm.querySelectorAll('input, textarea');
      formInputs.forEach(input => {
        input.addEventListener('input', function() {
          formData[this.name] = this.value;
        });
      });
    }
  }
  
  // אתחול העמוד
  createPageStructure();
});