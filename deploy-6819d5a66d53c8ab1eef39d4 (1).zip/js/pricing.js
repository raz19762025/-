// מידע על המכשירים
const devices = [
  {
    id: "samsung",
    type: "phone",
    image: "https://ucarecdn.com/ce267825-3d95-4249-bd00-de489fe5047e/",
    name: "סמסונג",
    models: [
      { id: "galaxy_s24_ultra", name: "Galaxy S24 Ultra" },
      { id: "galaxy_s24_plus", name: "Galaxy S24+" },
      { id: "galaxy_s24", name: "Galaxy S24" },
      { id: "galaxy_s23_ultra", name: "Galaxy S23 Ultra" },
      { id: "galaxy_s23_plus", name: "Galaxy S23+" },
      { id: "galaxy_s23", name: "Galaxy S23" },
      { id: "galaxy_s22_ultra", name: "Galaxy S22 Ultra" },
      { id: "galaxy_s22_plus", name: "Galaxy S22+" },
      { id: "galaxy_s22", name: "Galaxy S22" },
      { id: "galaxy_s21_ultra", name: "Galaxy S21 Ultra" },
      { id: "galaxy_s21_plus", name: "Galaxy S21+" },
      { id: "galaxy_s21", name: "Galaxy S21" },
      { id: "galaxy_s20_ultra", name: "Galaxy S20 Ultra" },
      { id: "galaxy_s20_plus", name: "Galaxy S20+" },
      { id: "galaxy_s20", name: "Galaxy S20" },
      { id: "galaxy_s10_plus", name: "Galaxy S10+" },
      { id: "galaxy_s10", name: "Galaxy S10" },
      { id: "galaxy_s9_plus", name: "Galaxy S9+" },
      { id: "galaxy_s9", name: "Galaxy S9" },
      { id: "galaxy_s8_plus", name: "Galaxy S8+" },
      { id: "galaxy_s8", name: "Galaxy S8" },
      { id: "galaxy_s7_edge", name: "Galaxy S7 Edge" },
      { id: "galaxy_s7", name: "Galaxy S7" },
      { id: "galaxy_s6_edge_plus", name: "Galaxy S6 Edge+" },
      { id: "galaxy_s6_edge", name: "Galaxy S6 Edge" },
      { id: "galaxy_s6", name: "Galaxy S6" },
    ],
  },
  {
    id: "apple",
    type: "phone",
    image:
      "https://ucarecdn.com/c17c2ba0-0b78-4b78-abf7-c7ed729e7f6a/-/format/auto/",
    name: "אייפון",
    models: [
      { id: "iphone_16_pro_max", name: "iPhone 16 Pro Max" },
      { id: "iphone_16_pro", name: "iPhone 16 Pro" },
      { id: "iphone_16_plus", name: "iPhone 16 Plus" },
      { id: "iphone_16", name: "iPhone 16" },
      { id: "iphone_15_pro_max", name: "iPhone 15 Pro Max" },
      { id: "iphone_15_pro", name: "iPhone 15 Pro" },
      { id: "iphone_15_plus", name: "iPhone 15 Plus" },
      { id: "iphone_15", name: "iPhone 15" },
      { id: "iphone_14_pro_max", name: "iPhone 14 Pro Max" },
      { id: "iphone_14_pro", name: "iPhone 14 Pro" },
      { id: "iphone_14_plus", name: "iPhone 14 Plus" },
      { id: "iphone_14", name: "iPhone 14" },
      { id: "iphone_13_pro_max", name: "iPhone 13 Pro Max" },
      { id: "iphone_13_pro", name: "iPhone 13 Pro" },
      { id: "iphone_13", name: "iPhone 13" },
      { id: "iphone_12_pro_max", name: "iPhone 12 Pro Max" },
      { id: "iphone_12_pro", name: "iPhone 12 Pro" },
      { id: "iphone_12", name: "iPhone 12" },
      { id: "iphone_11_pro_max", name: "iPhone 11 Pro Max" },
      { id: "iphone_11_pro", name: "iPhone 11 Pro" },
      { id: "iphone_11", name: "iPhone 11" },
      { id: "iphone_xs_max", name: "iPhone XS Max" },
      { id: "iphone_xs", name: "iPhone XS" },
      { id: "iphone_xr", name: "iPhone XR" },
      { id: "iphone_x", name: "iPhone X" },
      { id: "iphone_8_plus", name: "iPhone 8 Plus" },
      { id: "iphone_8", name: "iPhone 8" },
      { id: "iphone_7_plus", name: "iPhone 7 Plus" },
      { id: "iphone_7", name: "iPhone 7" },
      { id: "iphone_6s_plus", name: "iPhone 6s Plus" },
      { id: "iphone_6s", name: "iPhone 6s" },
      { id: "iphone_6_plus", name: "iPhone 6 Plus" },
      { id: "iphone_6", name: "iPhone 6" },
      { id: "iphone_5s", name: "iPhone 5s" },
      { id: "iphone_5", name: "iPhone 5" },
      { id: "iphone_4s", name: "iPhone 4s" },
      { id: "iphone_4", name: "iPhone 4" },
    ],
  },
  {
    id: "xiaomi",
    type: "phone",
    image: "https://ucarecdn.com/d0416ee8-c5e0-4b8a-89b0-61fe6abf8d5d/",
    name: "שיאומי",
    models: [
      { id: "xiaomi_14_pro", name: "Xiaomi 14 Pro" },
      { id: "xiaomi_14", name: "Xiaomi 14" },
      { id: "xiaomi_13_pro", name: "Xiaomi 13 Pro" },
      { id: "xiaomi_13", name: "Xiaomi 13" },
      { id: "xiaomi_12_pro", name: "Xiaomi 12 Pro" },
      { id: "xiaomi_12", name: "Xiaomi 12" },
      { id: "xiaomi_11_ultra", name: "Xiaomi 11 Ultra" },
      { id: "xiaomi_11_pro", name: "Xiaomi 11 Pro" },
      { id: "xiaomi_11", name: "Xiaomi 11" },
      { id: "xiaomi_10_pro", name: "Xiaomi 10 Pro" },
      { id: "xiaomi_10", name: "Xiaomi 10" },
      { id: "redmi_note_12_pro", name: "Redmi Note 12 Pro" },
      { id: "redmi_note_12", name: "Redmi Note 12" },
      { id: "redmi_note_11_pro", name: "Redmi Note 11 Pro" },
      { id: "redmi_note_11", name: "Redmi Note 11" },
      { id: "poco_f5_pro", name: "POCO F5 Pro" },
      { id: "poco_f5", name: "POCO F5" },
      { id: "poco_x5_pro", name: "POCO X5 Pro" },
      { id: "poco_x5", name: "POCO X5" },
    ],
  },
  {
    id: "laptops",
    type: "computer",
    image:
      "https://ucarecdn.com/13ff9bdb-0ed8-4aee-8b1e-8bdf5359a245/-/format/auto/",
    name: "מחשבים ניידים",
    models: [
      { id: "macbook_pro", name: "MacBook Pro" },
      { id: "macbook_air", name: "MacBook Air" },
      { id: "dell_xps", name: "Dell XPS" },
      { id: "lenovo_thinkpad", name: "Lenovo ThinkPad" },
      { id: "hp_spectre", name: "HP Spectre" },
      { id: "asus_zenbook", name: "Asus ZenBook" },
    ],
  },
  {
    id: "desktop",
    type: "computer",
    image:
      "https://ucarecdn.com/07209ba6-79a4-4733-8761-f9cd3b2050b7/-/format/auto/",
    name: "מחשבים נייחים",
    models: [
      {
        id: "imac",
        name: "iMac",
        repairs: ["מסך", "כונן קשיח", "זיכרון RAM", "ספק כוח", "מאוורר"],
      },
      {
        id: "mac_mini",
        name: "Mac Mini",
        repairs: ["כונן קשיח", "זיכרון RAM", "ספק כוח", "מאוורר"],
      },
      {
        id: "mac_studio",
        name: "Mac Studio",
        repairs: ["כונן קשיח", "זיכרון RAM", "ספק כוח", "מאוורר"],
      },
      {
        id: "custom_pc",
        name: "מחשב מותאם אישית",
        repairs: [
          "לוח אם",
          "מעבד",
          "כרטיס מסך",
          "זיכרון RAM",
          "כונן קשיח",
          "ספק כוח",
          "מאוורר",
        ],
      },
      {
        id: "gaming_pc",
        name: "מחשב גיימינג",
        repairs: [
          "לוח אם",
          "מעבד",
          "כרטיס מסך",
          "זיכרון RAM",
          "כונן קשיח",
          "ספק כוח",
          "מאוורר",
        ],
      },
      {
        id: "office_pc",
        name: "מחשב משרדי",
        repairs: [
          "לוח אם",
          "מעבד",
          "כרטיס מסך",
          "זיכרון RAM",
          "כונן קשיח",
          "ספק כוח",
          "מאוורר",
        ],
      },
    ],
  },
];

// מחירונים
const prices = {
  iphone_14_pro_max: {
    screen: {
      original: 1899,
      copy: 799,
    },
    charging_port: 299,
    front_camera: 399,
    rear_camera: 599,
    back_cover: 349,
  },
  iphone_14_pro: {
    screen: {
      original: 1699,
      copy: 749,
    },
    charging_port: 299,
    front_camera: 349,
    rear_camera: 549,
    back_cover: 329,
  },
  galaxy_s23_ultra: {
    screen: {
      original: 1599,
      copy: 699,
    },
    charging_port: 279,
    front_camera: 299,
    rear_camera: 499,
    back_cover: 299,
  },
  xiaomi_13_pro: {
    screen: {
      original: 1299,
      copy: 599,
    },
    charging_port: 249,
    front_camera: 299,
    rear_camera: 449,
    back_cover: 279,
  },
  macbook_pro: {
    screen: {
      original: 2499,
      copy: 1299,
    },
    charging_port: 399,
    front_camera: 299,
    rear_camera: 299,
    back_cover: 599,
  },
};

// משתנים גלובליים למצב האפליקציה
let selectedDevice = null;
let selectedModel = "";
let isAccessibilityOpen = false;
let fontSize = 16;
let isLoggedIn = false;
let selectedPart = "";
let selectedQuality = "";
let showCustomerForm = false;
let customerInfo = {
  name: "",
  phone: "",
  address: "",
};

// פונקציה ראשית להתחלת האפליקציה
document.addEventListener("DOMContentLoaded", function () {
  // יצירת המבנה הבסיסי של העמוד
  createBasicStructure();
  
  // יצירת כרטיסיות המכשירים
  renderDevices();
  
  // הוספת כפתורי פעולה קבועים
  addActionButtons();
  
  // עדכון גודל טקסט התחלתי
  updateFontSize();
});

// יצירת המבנה הבסיסי של העמוד
function createBasicStructure() {
  const root = document.getElementById("root") || document.body;
  root.innerHTML = `
    <div id="app" class="min-h-screen bg-gray-50 font-heebo" dir="rtl">
      <header class="bg-white shadow-sm py-16 px-6 relative">
        <div class="max-w-4xl mx-auto">
          <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-6 text-gray-900">
            המעבדה הניידת באר שבע
          </h1>
          <p class="text-xl md:text-2xl text-gray-600 text-center">
            תיקון מכשירים ניידים ומחשבים במקום אחד
          </p>
        </div>
      </header>
      
      <main class="container mx-auto px-4 md:px-6 py-8 md:py-16">
        <div id="devices-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          <!-- כאן יתווספו כרטיסיות המכשירים -->
        </div>
      </main>
      
      <div id="whatsapp-button" class="fixed bottom-6 right-6 z-50">
        <!-- כפתור וואטסאפ -->
      </div>
      
      <div id="accessibility-container" class="fixed bottom-6 left-6 z-50">
        <!-- אפשרויות נגישות -->
      </div>
    </div>
  `;
}

// עדכון גודל הטקסט בעמוד
function updateFontSize() {
  const appElement = document.getElementById("app");
  appElement.style.fontSize = `${fontSize}px`;
}

// הוספת כפתורי פעולה קבועים (וואטסאפ ונגישות)
function addActionButtons() {
  // כפתור וואטסאפ
  const whatsappButton = document.getElementById("whatsapp-button");
  whatsappButton.innerHTML = `
    <button
      onclick="window.open('https://wa.me/972508305885', '_blank')"
      class="bg-green-600 text-white p-4 rounded-full shadow-md hover:bg-green-700 transition-colors duration-300"
      aria-label="צור קשר בוואטסאפ"
    >
      <i class="fab fa-whatsapp text-2xl"></i>
    </button>
  `;
  
  // כפתור נגישות
  const accessibilityContainer = document.getElementById("accessibility-container");
  accessibilityContainer.innerHTML = `
    <button
      onclick="toggleAccessibility()"
      class="bg-gray-800 text-white p-4 rounded-full shadow-md hover:bg-gray-900 transition-colors duration-300"
      aria-label="הגדרות נגישות"
    >
      <i class="fas fa-universal-access text-2xl"></i>
    </button>
    
    <div id="accessibility-options" class="absolute bottom-20 left-0 bg-white p-4 rounded-lg shadow-md border border-gray-200" style="display: none;">
      <div class="flex flex-col gap-3">
        <button
          onclick="changeFontSize(2)"
          class="bg-gray-800 text-white px-6 py-2 rounded-md hover:bg-gray-900 transition-colors duration-300"
        >
          הגדל טקסט
        </button>
        <button
          onclick="changeFontSize(-2)"
          class="bg-gray-800 text-white px-6 py-2 rounded-md hover:bg-gray-900 transition-colors duration-300"
        >
          הקטן טקסט
        </button>
      </div>
    </div>
  `;
}

// פונקציה לפתיחה/סגירה של אפשרויות נגישות
function toggleAccessibility() {
  isAccessibilityOpen = !isAccessibilityOpen;
  const accessibilityOptions = document.getElementById("accessibility-options");
  accessibilityOptions.style.display = isAccessibilityOpen ? "block" : "none";
}

// פונקציה לשינוי גודל טקסט
function changeFontSize(change) {
  fontSize = Math.max(12, Math.min(24, fontSize + change));
  updateFontSize();
}

// יצירת כרטיסיות המכשירים
function renderDevices() {
  const devicesContainer = document.getElementById("devices-container");
  devicesContainer.innerHTML = "";
  
  devices.forEach(device => {
    const deviceCard = createDeviceCard(device);
    devicesContainer.appendChild(deviceCard);
  });
}

// יצירת כרטיסיית מכשיר בודדת
function createDeviceCard(device) {
  const isCurrentlySelected = selectedDevice && selectedDevice.id === device.id;
  
  // יצירת אלמנט הכרטיסייה
  const deviceCard = document.createElement("div");
  deviceCard.className = `p-6 border rounded-lg cursor-pointer transition-all duration-300 ${
    isCurrentlySelected
      ? "bg-gray-50 border-gray-200 shadow-md"
      : "border-gray-100 hover:border-gray-200 hover:shadow-sm"
  } w-full max-w-[450px] mx-auto`;
  deviceCard.id = `device-${device.id}`;
  
  // הוספת תוכן בסיסי לכרטיסייה
  deviceCard.innerHTML = `
    <div class="relative mb-6">
      <img
        src="${device.image}"
        alt="${device.name} ${device.type}"
        class="h-40 md:h-56 w-full object-contain transition-transform duration-300"
      />
      <div class="absolute top-3 right-3 bg-gray-800 text-white px-4 py-2 rounded-md font-heebo text-sm">
        ${device.type === "computer" ? "מחשב" : "טלפון"}
      </div>
    </div>
    <h3 class="text-center font-bold font-heebo text-xl md:text-2xl mb-4 text-gray-800">
      ${device.name}
    </h3>
  `;
  
  // הוספת אלמנטים אינטראקטיביים אם המכשיר נבחר
  if (isCurrentlySelected) {
    const interactiveContent = document.createElement("div");
    interactiveContent.className = "mt-6 space-y-4";
    interactiveContent.id = `${device.id}-details`;
    
    // יצירת תיבת בחירת דגם
    const modelSelect = createModelSelect(device);
    interactiveContent.appendChild(modelSelect);
    
    // הוספת תיבת בחירת חלק לתיקון אם דגם נבחר
    if (selectedModel) {
      const partSelect = createPartSelect();
      interactiveContent.appendChild(partSelect);
      
      // הוספת בחירת איכות אם נבחר תיקון מסך
      if (selectedPart === "screen") {
        const qualitySelect = createQualitySelect();
        interactiveContent.appendChild(qualitySelect);
      }
      
      // הצגת מחיר אם נבחרו כל הפרטים הדרושים
      if (selectedPart && selectedModel) {
        const priceDisplay = createPriceDisplay(device);
        interactiveContent.appendChild(priceDisplay);
      }
      
      // טופס לקוח או כפתור התחברות
      if (!isLoggedIn) {
        const loginButton = createLoginButton();
        interactiveContent.appendChild(loginButton);
      } else if (selectedPart && (selectedPart !== "screen" || selectedQuality)) {
        if (!showCustomerForm) {
          const continueButton = createContinueButton();
          interactiveContent.appendChild(continueButton);
        } else {
          const customerForm = createCustomerForm();
          interactiveContent.appendChild(customerForm);
        }
      }
    }
    
    deviceCard.appendChild(interactiveContent);
  }
  
  // הוספת מאזין לאירוע לחיצה
  deviceCard.addEventListener("click", () => selectDevice(device));
  
  return deviceCard;
}

// יצירת תיבת בחירת דגם
function createModelSelect(device) {
  const select = document.createElement("select");
  // עצירת click כדי לא לגרום לסגירת select
  select.addEventListener("click", e => e.stopPropagation());
  select.name = "model";
  select.className = "w-full p-3 md:p-4 border-2 rounded-xl mb-2 md:mb-3 font-heebo focus:ring-2 focus:border-transparent bg-white shadow-md text-base md:text-lg";
  select.id = `${device.id}-model-select`;
  
  // יצירת אפשרות ברירת מחדל
  let defaultOption = document.createElement("option");
  defaultOption.value = "";
  defaultOption.textContent = "בחר דגם";
  select.appendChild(defaultOption);
  
  // הוספת כל הדגמים של המכשיר
  device.models.forEach(model => {
    const option = document.createElement("option");
    option.value = model.id;
    option.textContent = model.name;
    option.className = "bg-white";
    select.appendChild(option);
  });
  
  // הגדרת הערך הנבחר הנוכחי
  if (selectedModel) {
    select.value = selectedModel;
  }
  
  // הוספת מאזין לאירוע שינוי
  select.addEventListener("change", (e) => {
    e.stopPropagation(); // מניעת בועה של האירוע
    selectedModel = e.target.value;
    selectedPart = "";
    selectedQuality = "";
    showCustomerForm = false;
    renderDevices(); // עדכון הממשק
  });
  
  return select;
}

// יצירת תיבת בחירת חלק לתיקון
function createPartSelect() {
  const select = document.createElement("select");
  // עצירת click כדי לא לגרום לסגירת select
  select.addEventListener("click", e => e.stopPropagation());
  select.name = "part";
  select.className = "w-full p-3 md:p-4 border-2 rounded-xl mb-2 md:mb-3 font-heebo focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white shadow-md text-base md:text-lg";
  
  // יצירת אפשרות ברירת מחדל
  let defaultOption = document.createElement("option");
  defaultOption.value = "";
  defaultOption.textContent = "בחר חלק לתיקון";
  select.appendChild(defaultOption);
  
  // הוספת אפשרויות חלקים
  const parts = [
    { value: "screen", text: "מסך" },
    { value: "charging_port", text: "שקע טעינה" },
    { value: "front_camera", text: "מצלמה קדמית (סלפי)" },
    { value: "rear_camera", text: "מצלמה אחורית (ראשית)" },
    { value: "back_cover", text: "כיסוי אחורי" }
  ];
  
  parts.forEach(part => {
    const option = document.createElement("option");
    option.value = part.value;
    option.textContent = part.text;
    select.appendChild(option);
  });
  
  // הגדרת הערך הנבחר הנוכחי
  if (selectedPart) {
    select.value = selectedPart;
  }
  
  // הוספת מאזין לאירוע שינוי
  select.addEventListener("change", (e) => {
    e.stopPropagation(); // מניעת בועה של האירוע
    selectedPart = e.target.value;
    if (selectedPart !== "screen") {
      selectedQuality = "";
    }
    renderDevices(); // עדכון הממשק
  });
  
  return select;
}

// יצירת תיבת בחירת איכות מסך
function createQualitySelect() {
  const select = document.createElement("select");
  // עצירת click כדי לא לגרום לסגירת select
  select.addEventListener("click", e => e.stopPropagation());
  select.name = "quality";
  select.className = "w-full p-3 md:p-4 border-2 rounded-xl mb-2 md:mb-3 font-heebo focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white shadow-md text-base md:text-lg";
  
  // יצירת אפשרות ברירת מחדל
  let defaultOption = document.createElement("option");
  defaultOption.value = "";
  defaultOption.textContent = "בחר איכות מסך";
  select.appendChild(defaultOption);
  
  // הוספת אפשרויות איכות
  const qualities = [
    { value: "original", text: "מקורי" },
    { value: "copy", text: "סופר קופי" }
  ];
  
  qualities.forEach(quality => {
    const option = document.createElement("option");
    option.value = quality.value;
    option.textContent = quality.text;
    select.appendChild(option);
  });
  
  // הגדרת הערך הנבחר הנוכחי
  if (selectedQuality) {
    select.value = selectedQuality;
  }
  
  // הוספת מאזין לאירוע שינוי
  select.addEventListener("change", (e) => {
    e.stopPropagation(); // מניעת בועה של האירוע
    selectedQuality = e.target.value;
    renderDevices(); // עדכון הממשק
  });
  
  return select;
}

// יצירת תצוגת מחיר
function createPriceDisplay(device) {
  const priceContainer = document.createElement("div");
  priceContainer.className = "bg-gradient-to-r from-blue-50 to-blue-100 p-4 md:p-6 rounded-xl border border-blue-200 mt-3 md:mt-4 transform hover:scale-[1.02] transition-all duration-300";
  
  const price = getCurrentPrice();
  
  priceContainer.innerHTML = `
    <div class="text-center font-bold text-xl md:text-2xl text-blue-800 mb-2 md:mb-3">
      מחיר משוער לתיקון:
    </div>
    <div class="text-center text-2xl md:text-3xl font-bold text-green-600 mb-2">
      ${price ? `₪${price.toLocaleString()}` : "לא זמין"}
    </div>
    <div class="text-center text-xs md:text-sm text-gray-600 bg-white/50 p-2 md:p-3 rounded-lg">
      *המחיר הסופי עשוי להשתנות בהתאם למצב המכשיר
    </div>
  `;
  
  return priceContainer;
}

// יצירת כפתור התחברות
function createLoginButton() {
  const loginButton = document.createElement("button");
  loginButton.className = "w-full mt-3 md:mt-4 bg-blue-600 text-white p-3 md:p-4 rounded-xl hover:bg-blue-700 transition-colors duration-300 font-heebo font-bold shadow-lg text-base md:text-lg";
  loginButton.textContent = "התחבר כדי להמשיך";
  
  loginButton.addEventListener("click", (e) => {
    e.stopPropagation(); // מניעת בועה של האירוע
    isLoggedIn = true;
    renderDevices(); // עדכון הממשק
  });
  
  return loginButton;
}

// יצירת כפתור המשך להזנת פרטים
function createContinueButton() {
  const continueButton = document.createElement("button");
  continueButton.className = "w-full mt-3 md:mt-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white p-3 md:p-4 rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-300 font-heebo font-bold shadow-lg text-base md:text-lg transform hover:scale-105";
  continueButton.textContent = "המשך להזנת פרטים";
  
  continueButton.addEventListener("click", (e) => {
    e.stopPropagation(); // מניעת בועה של האירוע
    showCustomerForm = true;
    renderDevices(); // עדכון הממשק
  });
return continueButton;
}

// יצירת טופס פרטי לקוח
function createCustomerForm() {
  const formContainer = document.createElement("div");
  // מניעת סגירת הכרטיסייה בעת לחיצה בתוך טופס לקוח
  formContainer.addEventListener("click", e => e.stopPropagation());
  formContainer.className = "bg-white p-4 md:p-6 rounded-xl shadow-lg space-y-3 md:space-y-4";
  
  formContainer.innerHTML = `
    <h4 class="text-lg md:text-xl font-bold text-center mb-3 md:mb-4 text-[#1a4b5c]">
      הזן את פרטיך
    </h4>
    <input
      type="text"
      name="name"
      id="customer-name"
      placeholder="שם מלא"
      value="${customerInfo.name}"
      class="w-full p-3 md:p-4 border-2 rounded-xl font-heebo focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
    />
    <input
      type="tel"
      name="phone"
      id="customer-phone"
      placeholder="מספר טלפון"
      value="${customerInfo.phone}"
      class="w-full p-3 md:p-4 border-2 rounded-xl font-heebo focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
    />
    <input
      type="text"
      name="address"
      id="customer-address"
      placeholder="כתובת מלאה"
      value="${customerInfo.address}"
      class="w-full p-3 md:p-4 border-2 rounded-xl font-heebo focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
    />
    <div class="flex gap-3 md:gap-4">
      <button
        id="location-button"
        class="flex-1 p-3 md:p-4 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors duration-300 font-heebo font-bold shadow-lg text-base md:text-lg"
      >
        <i class="fas fa-map-marker-alt mr-2"></i>
        שלח מיקום נוכחי
      </button>
    </div>
    <button
      id="whatsapp-send-button"
      class="w-full mt-3 md:mt-4 p-3 md:p-4 rounded-xl transition-all duration-300 font-heebo font-bold shadow-lg text-base md:text-lg flex items-center justify-center gap-2 md:gap-3 ${
        customerInfo.name && customerInfo.phone
          ? "bg-green-500 hover:bg-green-600 text-white transform hover:scale-105"
          : "bg-gray-300 cursor-not-allowed text-gray-500"
      }"
      ${(!customerInfo.name || !customerInfo.phone) ? "disabled" : ""}
    >
      <i class="fab fa-whatsapp text-xl md:text-2xl"></i>
      שלח הודעה בוואטסאפ
    </button>
  `;
  
  // הוספת מאזיני אירועים לאחר יצירת האלמנטים
  setTimeout(() => {
    // מאזין לשדה שם
    const nameInput = document.getElementById("customer-name");
    nameInput.addEventListener("input", (e) => {
      e.stopPropagation();
      customerInfo.name = e.target.value;
      updateWhatsAppButtonState();
    });
    
    // מאזין לשדה טלפון
    const phoneInput = document.getElementById("customer-phone");
    phoneInput.addEventListener("input", (e) => {
      e.stopPropagation();
      customerInfo.phone = e.target.value;
      updateWhatsAppButtonState();
    });
    
    // מאזין לשדה כתובת
    const addressInput = document.getElementById("customer-address");
    addressInput.addEventListener("input", (e) => {
      e.stopPropagation();
      customerInfo.address = e.target.value;
    });
    
    // מאזין לכפתור מיקום
    const locationButton = document.getElementById("location-button");
    locationButton.addEventListener("click", (e) => {
      e.stopPropagation();
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          const { latitude, longitude } = position.coords;
          customerInfo.address = `${customerInfo.address} [${latitude}, ${longitude}]`;
          document.getElementById("customer-address").value = customerInfo.address;
        });
      }
    });
    
    // מאזין לכפתור שליחת וואטסאפ
    const whatsappButton = document.getElementById("whatsapp-send-button");
    whatsappButton.addEventListener("click", (e) => {
      e.stopPropagation();
      if (customerInfo.name && customerInfo.phone) {
        openWhatsApp();
      }
    });
  }, 0);
  
  return formContainer;
}

// עדכון מצב כפתור וואטסאפ (פעיל/לא פעיל)
function updateWhatsAppButtonState() {
  const whatsappButton = document.getElementById("whatsapp-send-button");
  if (whatsappButton) {
    if (customerInfo.name && customerInfo.phone) {
      whatsappButton.classList.remove("bg-gray-300", "cursor-not-allowed", "text-gray-500");
      whatsappButton.classList.add("bg-green-500", "hover:bg-green-600", "text-white", "transform", "hover:scale-105");
      whatsappButton.disabled = false;
    } else {
      whatsappButton.classList.add("bg-gray-300", "cursor-not-allowed", "text-gray-500");
      whatsappButton.classList.remove("bg-green-500", "hover:bg-green-600", "text-white", "transform", "hover:scale-105");
      whatsappButton.disabled = true;
    }
  }
}

// בחירת מכשיר
function selectDevice(device) {
  selectedDevice = device;
  renderDevices();
}

// קבלת המחיר הנוכחי בהתאם לבחירות המשתמש
function getCurrentPrice() {
  if (!selectedModel || !selectedPart) {
    return null;
  }
  
  if (selectedPart === "screen") {
    const screenPrices = getPriceForModelAndPart(selectedModel, "screen");
    return selectedQuality === "original" ? screenPrices?.original : screenPrices?.copy;
  }
  
  return getPriceForModelAndPart(selectedModel, selectedPart);
}

// קבלת מחיר לפי דגם וחלק
function getPriceForModelAndPart(modelId, partType) {
  return prices[modelId]?.[partType] || null;
}

// פתיחת וואטסאפ עם הודעה מוכנה
function openWhatsApp() {
  let price = getCurrentPrice();
  
  const partNames = {
    screen: "מסך",
    charging_port: "שקע טעינה",
    front_camera: "מצלמה קדמית (סלפי)",
    rear_camera: "מצלמה אחורית (ראשית)",
    back_cover: "כיסוי אחורי",
  };
  
  const message = `היי, אני מעוניין בתיקון ${
    selectedDevice.type === "computer" ? "מחשב" : "מכשיר"
  } 
דגם: ${selectedDevice.name} ${selectedModel.replace(/_/g, " ")}
סוג התיקון: ${partNames[selectedPart]}
${
  selectedPart === "screen"
    ? `איכות: ${selectedQuality === "original" ? "מקורי" : "סופר קופי"}`
    : ""
}
מחיר מוערך: ${price ? `${price.toLocaleString()} ₪` : "לא זמין"}

פרטי לקוח:
שם: ${customerInfo.name}
טלפון: ${customerInfo.phone}
${customerInfo.address ? `כתובת: ${customerInfo.address}` : ""}`;

  const phoneNumber = "972508305885";
  const whatsappURL = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;
  window.open(whatsappURL, "_blank");
}

// הוספת קובץ CSS חיצוני
function addStylesheet() {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css";
  document.head.appendChild(link);
  
  // הוספת Font Awesome
  const fontAwesome = document.createElement("link");
  fontAwesome.rel = "stylesheet";
  fontAwesome.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css";
  document.head.appendChild(fontAwesome);
  
  // הוספת פונט Heebo מ-Google Fonts
  const heeboFont = document.createElement("link");
  heeboFont.rel = "stylesheet";
  heeboFont.href = "https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700;800&display=swap";
  document.head.appendChild(heeboFont);
  
  // הוספת סגנונות מותאמים אישית
  const customStyles = document.createElement("style");
  customStyles.textContent = `
    body {
      font-family: 'Heebo', sans-serif;
    }
    
    .font-heebo {
      font-family: 'Heebo', sans-serif;
    }
    
    /* תיקונים לתצוגה RTL */
    [dir="rtl"] .mr-2 {
      margin-right: 0;
      margin-left: 0.5rem;
    }
    
    /* שקיפות חלקית עבור רקעים */
    .bg-white\/50 {
      background-color: rgba(255, 255, 255, 0.5);
    }
  `;
  document.head.appendChild(customStyles);
}

// אתחול האפליקציה בטעינת העמוד
window.onload = function() {
  addStylesheet();
  createBasicStructure();
  renderDevices();
  addActionButtons();
  updateFontSize();
};

// הוספת קוד HTML הבסיסי לעמוד
// יש להוסיף לקובץ ה-HTML הבא:
/*
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>המעבדה הניידת באר שבע</title>
</head>
<body>
  <div id="root"></div>
  <script src="app.js"></script>
</body>
</html>
*/